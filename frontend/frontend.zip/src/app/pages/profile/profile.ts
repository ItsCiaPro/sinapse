import { Component } from '@angular/core';
import { SidebarNav } from '../../components/sidebar-nav/sidebar-nav';

@Component({
  selector: 'app-profile',
  imports: [SidebarNav],
  templateUrl: './profile.html',
  styleUrl: './profile.css',
})
export class Profile {

}
