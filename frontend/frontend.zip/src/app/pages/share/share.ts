import { Component } from '@angular/core';
import { SidebarNav } from '../../components/sidebar-nav/sidebar-nav';

@Component({
  selector: 'app-share',
  imports: [SidebarNav],
  templateUrl: './share.html',
  styleUrl: './share.css',
})
export class Share {

}
